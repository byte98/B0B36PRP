#include <stdio.h>
#include <stdlib.h>
#include <string.h>


/* Declaration of global variables */
int size = 1;
char alphabet[] = "ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz"; //count = ALPHABET_COUNT = 52
int size_decoded = 1;
int size_encoded = 1;
int real_size_decoded = 0;
int real_size_encoded = 0;

#define ALPHABET_COUNT 52
#define bool int
#define TRUE 1
#define FALSE 0


//Definitions of colors in shell
#define RED   "\x1B[1;31m"
#define GRN   "\x1B[1;32m"
#define YEL   "\x1B[1;33m"
#define BLU   "\x1B[1;34m"
#define MAG   "\x1B[1;35m"
#define CYN   "\x1B[1;36m"
#define WHT   "\x1B[1;37m"
#define RESET "\x1B[1;0m"


/* Declaration of functions */

	//Function to print array of characters (just for debugging)
	void printCharArray(char *input, int count);

	//Function to shift letter
	char shiftLetter(char letter, int distance);

	//Function to shift string
	void shiftString(char *string, int count, int distance);

	//Function to get index of element in array
	int indexOf(char *array, int count, char value);

	//Function to get count of same letters
	int getSameLetters(char *string1, char *string2, int count1, int count2);

	//Function to copy array elements into another array
	void copyArray(char *input, char *output, int count);

	//Function to decode message using partly listened message
	void decode(char *str1, char *str2, int count, char *output, bool print_debug);

	//Function to check if arguments of main has searched argument
	bool hasArgument(char *argv[], int argc, char *arg);

	//Main program for compulsory part of homework
	int mainCompulsory(bool log);

	//Main program for optional part of homework
	int mainOptional(bool log);

	//Function to compute Levenshtein Distance of two strings
	int getLevenshteinDistance(char *str1, int count1, char*str2, int count2);

	//Function to decode message using partly listened message and Levenshtein Distance
	void decodeAdvanced(char *str1, char *str2, int count1, int count2, char *output, bool print_debug);

	//Function to print char n times
	void printNTimes(char input, int n);

	//Funtcion to print 2D array of integers (just for debugging)
	void print2DIntArray(int **array, int rows, int cols, char *format);

	//Function to print array of integers (jusr for debugging)
	void printIntArray(int *array, int count, char *format);


/* The main program */
int main(int argc, char *argv[])
{		

	if (hasArgument(argv, argc, "-prp-optional") == TRUE)
	{
		return mainOptional(hasArgument(argv, argc, "-log"));
	}
	else
	{
		return mainCompulsory(hasArgument(argv, argc, "-log"));
	}	
}

//Main program for compulsory part of homework
int mainCompulsory(bool log)
{
	char *message = (char *)malloc(size * 64 * sizeof(char));
	int index = 0;
	char input = 0;

	do
	{
		input = getchar();
		if ((input >= 65 && input <= 122 && !(input > 90 && input < 97)))
		{
			if ((index + 1) >= size * 64)
			{

				size++;
				message = (char *)realloc(message, (size * 64 * sizeof(char)));
			}
			else
			{
				message[index] = input;
				index++;
			}

		}
		else if (input == '\n')
		{
			break;
		}
		else
		{
			fprintf(stderr, "Error: Chybny vstup!\n");

			free(message);
			return 100;
		}

	} while (input != EOF && (input >= 65 && input <= 122 && !(input > 90 && input < 97)));


	char *listened = (char *)malloc(size * 64 * sizeof(char));
	int index2 = 0;
	do
	{
		input = getchar();
		if (index2 > index)
		{
			fprintf(stderr, "Error: Chybna delka vstupu!\n");
		}
		else if (input >= 65 && input <= 122 && !(input > 90 && input < 97))
		{
			if ((index2 + 1) >= size * 64)
			{
				fprintf(stderr, "Error: Chybna delka vstupu!\n");
				free(message);
				free(listened);
				return 101;
			}

			listened[index2] = input;
			index2++;

		}
		else if (index2 < index && input == '\n')
		{
			fprintf(stderr, "Error: Chybna delka vstupu!\n");

			free(message);
			free(listened);
			return 101;
		}
		else if (input == '\n')
		{
			break;
		}
		else
		{
			fprintf(stderr, "Error: Chybny vstup!\n");
			free(message);
			free(listened);
			return 100;
		}


	} while (input != EOF && (input >= 65 && input <= 122 && !(input > 90 && input < 97)));

	decode(listened, message, index, listened, log);

	free(message);
	free(listened);
	return 0;
}

//Main program for optional part of homework
int mainOptional(bool log)
{
	//Loading encoded message
	char *message_encoded = (char *)malloc(size_encoded * 64 * sizeof(char));
	int index = 0;
	char input = 0;

	do
	{
		input = getchar();
		if ((input >= 65 && input <= 122 && !(input > 90 && input < 97)))
		{
			if ((index + 1) >= size_encoded * 64)
			{

				size_encoded++;
				message_encoded = (char *)realloc(message_encoded, (size_encoded * 64 * sizeof(char)));
			}
			else
			{
				message_encoded[index] = input;
				index++;
			}

		}
		else if (input == '\n')
		{
			break;
		}
		else
		{
			fprintf(stderr, "Error: Chybny vstup!\n");

			free(message_encoded);
			return 100;
		}

	} while (input != EOF && (input >= 65 && input <= 122 && !(input > 90 && input < 97)));

	real_size_encoded = index;
	

	//Loading decode message
	char *message_decoded = (char *)malloc(size_decoded * 64 * sizeof(char));
	index = 0;
	input = 0;

	do
	{
		input = getchar();
		if ((input >= 65 && input <= 122 && !(input > 90 && input < 97)))
		{
			if ((index + 1) >= size_decoded * 64)
			{

				size_decoded++;
				message_decoded = (char *)realloc(message_decoded, (size_decoded * 64 * sizeof(char)));
			}
			else
			{
				message_decoded[index] = input;
				index++;
			}

		}
		else if (input == '\n')
		{
			break;
		}
		else
		{
			fprintf(stderr, "Error: Chybny vstup!\n");

			free(message_decoded);
			return 100;
		}

	} while (input != EOF && (input >= 65 && input <= 122 && !(input > 90 && input < 97)));

	real_size_decoded = index;

	char *reti = malloc(real_size_encoded * sizeof(char));

	decodeAdvanced(message_encoded, message_decoded, real_size_encoded, real_size_decoded, reti, log);

	free(reti);
	free(message_decoded);
	free(message_encoded);

	return 0;
}


//Function to print array of integers (jusr for debugging)
void printIntArray(int *array, int count, char *format)
{
	for (int i = 0; i < count; i++)
	{
		printf(format, array[i]);
	}
}

//Funtcion to print 2D array (just for debugging)
void print2DIntArray(int **array, int rows, int cols, char *format)
{
	for (int i = 0; i < rows; i++)
	{
		printIntArray(array[i], cols, format);
		printf("\n");
	}
}

//Function to decode message using partly listened message and Levenshtein Distance
void decodeAdvanced(char *str1, char *str2, int count1, int count2, char *output, bool print_debug)
{
	if (print_debug == TRUE)
	{
		printf("\n");
		printNTimes('*', 64);
		printf("\n");
		printNTimes(' ', 21);
		printf(WHT "ADVANCED DECODING LOG" RESET);
		printNTimes(' ', 21);
		printf("\n");
		printNTimes('-', 64);
		printNTimes(' ', 28);
		printf("\n");
		printf(YEL "SETTINGS" RESET);
		printNTimes(' ', 28);
		printf("\n");
		printf(WHT "ENCODED MESSAGE:\n" RESET);
		printCharArray(str1, count1);
		printf(WHT "\nPARTLY DECODED MESSAGE:\n" RESET);
		printCharArray(str2, count1);
		printf("\n\n");
		printNTimes(' ', 16);
		printf(WHT "ACTION:" RESET " SHIFTING ENCODED STRING");
		printNTimes(' ', 17);
		printf("\n");
		printNTimes(' ', 13);
		printf(WHT "OBJECTIVE:" RESET " Find string, which has");
		printNTimes(' ', 12);
		printf("\n");
		printNTimes(' ', 13);
		printf("           the lowest Levensthein distance.");
		printNTimes(' ', 3);
		printf("\n\n\n");
		printNTimes('-', 64);
		printf("\n");
		printf(MAG "ROW NUMBER" RESET);
		printf("|");
		printf(BLU "DECODED STRING " RESET);
		printf("|");
		printf(GRN "MATCHING LETTERS" RESET);
		printf("|");
		printf(CYN "LEVENSHTEIN DISTANCE " RESET);
		printf("\n");
		printNTimes('-', 64);
		printf("\n");
	}
	int i = 0;

	int best_letters = getLevenshteinDistance(str1, count1, str2, count2);
	char *best_string = malloc(count1 * sizeof(char));

	for (i = 1; i <= 52; i++)
	{
		shiftString(str1, count1, -1);
		int sl = getSameLetters(str1, str2, count1, count1);
		int ld = getLevenshteinDistance(str1, count1, str2, count2);
		if (ld < best_letters)
		{
			best_letters = ld;
			copyArray(str1, best_string, count1);
		}

		if (print_debug == TRUE)
		{
			printf(MAG "%3i" RESET "|" BLU, i);
			printCharArray(str1, count1);
			printf(RESET "|" GRN "%3i" RESET "|" CYN "%i" RESET "\n", sl, ld);
		}
	}

	if (print_debug == TRUE)
	{
		printf("\n");
		printNTimes(' ', 24);
		printf(RED "RESULT OF ACTION" RESET);
		printNTimes(' ', 24);
		printf("\n");
		printf(MAG "%3i" RESET "|" BLU, i);
		printCharArray(best_string, count1);
		printf(RESET "|" GRN "%3i" RESET "|" CYN "%3i" RESET "\n", getSameLetters(best_string, str2, count1, count1), best_letters);
		printf("\n");
		printNTimes('-', 64);
		printf("\n" YEL "DECODED MESSAGE:" RESET "\n" WHT);
		printCharArray(best_string, count1);
		printf(RESET "\n");
		printNTimes('*', 64);
		printf("\n");
	}
	else
	{
		printCharArray(best_string, count1);
		printf("\n");
	}

	free(best_string);
	
}

//Function to print char n times
void printNTimes(char input, int n)
{
	for (int i = 1; i <= n; i++)
	{
		printf("%c", input);
	}
}

//Function to copy array elements into another array
void copyArray(char *input, char *output, int count)
{
	for(int i = 0; i < count; i++)
	{
		output[i] = input[i];
	}
}

//Function to decode message using partly listened message
void decode(char *str1, char *str2, int count, char *output, bool print_debug)
{

	if (print_debug == TRUE)
	{
		printf("\n");
		printNTimes('*', 64);
		printf("\n");
		printNTimes(' ', 22);
		printf(WHT "SIMPLE DECODING LOG" RESET);
		printNTimes(' ', 23);
		printf("\n");
		printNTimes('-', 64);
		printNTimes(' ', 28);
		printf("\n");
		printf(YEL "SETTINGS" RESET);
		printNTimes(' ', 28);
		printf("\n");
		printf(WHT "ENCODED MESSAGE:\n" RESET);
		printCharArray(str2, count);
		printf(WHT "\nPARTLY DECODED MESSAGE:\n" RESET);
		printCharArray(str1, count);
		printf("\n\n");
		printNTimes(' ', 16);
		printf(WHT "ACTION:" RESET " SHIFTING ENCODED STRING");
		printNTimes(' ', 17);
		printf("\n");
		printNTimes(' ', 13);
		printf(WHT "OBJECTIVE:" RESET " Find string, which has the");
		printNTimes(' ', 12);
		printf("\n");
		printNTimes(' ', 13);
		printf("           biggest count of matching letters.");
		printNTimes(' ', 3);
		printf("\n\n");
		printf("\n");
		printNTimes('-', 64);
		printf("\n");
		printf(MAG "ROW NUMBER" RESET);
		printf(" | ");
		printNTimes(' ', 8);
		printf(BLU "DECODED STRING" RESET);
		printNTimes(' ', 8);
		printf(" | ");
		printf(GRN "MATCHING LETTERS" RESET);
		printf("\n");
		printNTimes('-', 64);
		printf("\n");
	}
	
	int i = 0;

	char *reti = (char *)malloc(count * sizeof(char));
	int count_same = 0;
	for (i = 1; i <= 52; i++)
	{
		shiftString(str2, count, -1);
		int s = getSameLetters(str1, str2, count, count);
		if (s > count_same)
		{
			count_same = s;
			copyArray(str2, reti, count);			
		}

		if (print_debug == TRUE)
		{
			printf(MAG "%3i" RESET " | " BLU, i);
			printCharArray(str2, count);
			printf(RESET " | " GRN "%3i" RESET, s);
			printf("\n");
		}
	}

	if (print_debug == TRUE)
	{
		printf("\n");
		printNTimes(' ', 24);
		printf(RED "RESULT OF ACTION" RESET);
		printNTimes(' ', 24);
		printf("\n");
		printf(MAG "%3i" RESET " | " BLU, i);
		printCharArray(reti, count);
		printf(RESET " | " GRN "%3i" RESET "\n", count_same);
		printf("\n");
		printNTimes('-', 64);
		printf("\n" YEL "DECODED MESSAGE:" RESET "\n" WHT);
		printCharArray(reti, count);
		printf(RESET "\n");
		printNTimes('*', 64);
		printf("\n");
	}
	else
	{
		printCharArray(reti, count);
		printf("\n");
	}
	

free(reti);
}

//Function to print array (just for debugging)
void printCharArray(char *input, int count)
{
	for (int i = 0; i < count; i++)
	{
		printf("%c", input[i]);
	}
}

//Function to shift string
void shiftString(char *string, int count, int distance)
{
	for (int i = 0; i < count; i++)
	{
		string[i] = shiftLetter(string[i], distance);
	}
}

//Function to get count of same letters
int getSameLetters(char *string1, char *string2, int count1, int count2)
{
	int reti = 0;
	int count;

	count = count1 < count2 ? count1 : count2;

	for (int i = 0; i < count; i++)
	{
		if (string1[i] == string2[i])
		{
			reti++;
		}
	}

	return reti;
}

//Function to shift letter
char shiftLetter(char letter, int distance)
{
	int index = indexOf(alphabet, ALPHABET_COUNT, letter);
	index += distance;
	while (index < 0)
	{
		index += ALPHABET_COUNT;
	}
	return alphabet[(index % ALPHABET_COUNT)];
}

//Function to get index of element in array
int indexOf(char *array, int count, char value)
{
	int index = 0;
	while (index < count && array[index] != value)
	{
		index++;
	}

	return (index == count ? -1 : index);
}

//Function to check if arguments of main has searched argument
bool hasArgument(char *argv[], int argc, char *arg)
{
	int i;
	for (i = 0; i < argc; i++)
	{
		if (strstr(argv[i], arg) != NULL)
		{
			return TRUE;
		}

	}
	return FALSE;
}

//Function to get minimum from array items
int getMin(int *numbers, int count);

//Function to compute Levenshtein Distance of two strings
int getLevenshteinDistance(char *str1, int count1, char*str2, int count2)
{
	
	int** matrix;

	matrix = malloc(count1 * sizeof(int*));
	for (int i = 0; i < count1; i++) {
		matrix[i] = malloc(count2 * sizeof(int));
	}
	


	for (int i = 0; i < count1; i++)
	{
		matrix[i][0] = i;
	}

	for (int i = 0; i < count2; i++)
	{
		matrix[0][i] = i;
	}
	
	for (int i = 1; i < count1; i++)
	{
		for (int j = 1; j < count2; j++)
		{
			if (str1[i] == str2[j])
			{
				matrix[i][j] = matrix[(i - 1)][(j - 1)];
			}
			else
			{
				int nums[] = { (matrix[(i - 1)][j] + 1) , (matrix[i][(j - 1)] + 1) , (matrix[(i - 1)][(j - 1)] + 1) };
				matrix[i][j] = getMin(nums, 3);
			
			}
				
		}
	}

	int reti = matrix[(count1 - 1)][(count2 - 1)];

	//printf("\nMATRIX\n");
	//print2DIntArray(matrix, count1, count2, "%3i");
	//printf("\n");

	for (int i = 0; i < count1; i++) {
		free(matrix[i]);
	}
	free(matrix);
	return reti;
}

//Function to get minimum from array items
int getMin(int *numbers, int count)
{
	int reti = numbers[0];
	for (int i = 0; i < count; i++)
	{
		if (numbers[i] < reti)
		{
			reti = numbers[i];
		}
	}
	return reti;
	return 0;
}
