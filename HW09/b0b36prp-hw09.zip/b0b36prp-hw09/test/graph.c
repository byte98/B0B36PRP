#include <stdlib.h>

#include "graph.h"

/* This is a testing file just to be able to compile the 
 * examples of binary files to convert graph from txt->bin
 * and bin -> txt
 */

// - function -----------------------------------------------------------------
graph_t* allocate_graph() 
{
   return NULL;
}

// - function -----------------------------------------------------------------
void free_graph(graph_t **graph)
{
}

// - function -----------------------------------------------------------------
void load_txt(const char *fname, graph_t *graph)
{
}

// - function -----------------------------------------------------------------
void load_bin(const char *fname, graph_t *graph)
{
}

// - function -----------------------------------------------------------------
void save_txt(const graph_t * const graph, const char *fname)
{
}

// - function -----------------------------------------------------------------
void save_bin(const graph_t * const graph, const char *fname)
{
}
